# AnyKernel2 Ramdisk Mod Script
# osm0sis @ xda-developers

## AnyKernel setup
# begin properties
properties() {
kernel.string=exNoShadez by nine7nine @ xda-developers
do.devicecheck=1
do.modules=0
do.cleanup=1
do.cleanuponabort=0
do.debug=0
device.name1=sailfish
device.name2=marlin
} # end properties

# shell variables
block=/dev/block/bootdevice/by-name/boot;
is_slot_device=1;


## AnyKernel methods (DO NOT CHANGE)
# import patching functions/variables - see for reference
. /tmp/anykernel/tools/ak2-core.sh;


## AnyKernel file attributes
# set permissions/ownership for included ramdisk files
chmod -R 750 $ramdisk/*;
chown -R root:root $ramdisk/*;

## AnyKernel install
dump_boot;

if [ -d $ramdisk/.subackup -o -d $ramdisk/.backup ]; then
  patch_cmdline "skip_override" "skip_override";
else
  patch_cmdline "skip_override" "";
fi;

# DEBUG PM 
# patch_cmdline "no_console_suspend=1" "no_console_suspend=1"

patch_prop $overlay/default.prop debug.sf.nobootanimation 1

# overlay stuff
if [ -d $ramdisk/.backup ]; then
  overlay=$ramdisk/overlay;
elif [ -d $ramdisk/.subackup ]; then
  overlay=$ramdisk/boot;
fi;

list="init.rc init.exnoshadez.rc";
for rdfile in $list; do
  rddir=$(dirname $rdfile);
  mkdir -p $overlay/$rddir;
  test ! -f $overlay/$rdfile && cp -rp /system/$rdfile $overlay/$rddir/;
done;

# init.rc
insert_line "$overlay/init.rc" "init.exnoshadez.rc" after "import /init.usb.configfs.rc" "import /init.exnoshadez.rc"
replace_file "$overlay/init.exnoshadez.rc" 750 "init.exnoshadez.rc"

write_boot;

## end install

